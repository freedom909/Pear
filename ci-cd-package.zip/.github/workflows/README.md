# GitHub Actions Workflows

This directory contains GitHub Actions workflows for continuous integration (CI), continuous deployment (CD), and security scanning of the application.

## CI Workflow

The CI workflow (`ci.yml`) runs on every push to the `main` branch and on pull requests. It performs the following tasks:

- Sets up Node.js and MongoDB
- Installs dependencies for both frontend and backend
- Runs linting and tests for both frontend and backend
- Builds both frontend and backend

## CD Workflow

The CD workflow (`cd.yml`) runs after the CI workflow completes successfully on the `main` branch. It performs the following tasks:

- Deploys the backend to Heroku
- Deploys the frontend to Vercel

## Security Scan Workflow

The security scan workflow (`security.yml`) runs weekly, on pushes to the `main` branch, on pull requests, and can be triggered manually. It performs the following tasks:

- Runs npm audit on both frontend and backend dependencies to check for known vulnerabilities
- Performs CodeQL analysis to identify potential security issues in the code

This workflow helps ensure that the application remains secure by regularly checking for vulnerabilities in dependencies and code.

## Dependabot Configuration

In addition to the workflows, this repository includes Dependabot configuration (`.github/dependabot.yml`) for automated dependency updates. Dependabot is configured to:

- Check for updates to npm dependencies in both frontend and backend directories weekly
- Check for updates to GitHub Actions monthly
- Create pull requests with appropriate labels for each update
- Group minor and patch updates to reduce the number of pull requests

This helps keep dependencies up-to-date and reduces security vulnerabilities by automatically creating pull requests when updates are available.

## Required Secrets

To use these workflows, you need to set up the following secrets in your GitHub repository settings:

### For CI Workflow

- `JWT_SECRET`: Secret key for JWT token generation
- `GOOGLE_CLIENT_ID`: Google OAuth client ID
- `GOOGLE_CLIENT_SECRET`: Google OAuth client secret
- `FACEBOOK_APP_ID`: Facebook OAuth app ID
- `FACEBOOK_APP_SECRET`: Facebook OAuth app secret

### For CD Workflow (Backend - Heroku)

- `HEROKU_API_KEY`: Your Heroku API key
- `HEROKU_APP_NAME`: Your Heroku app name
- `HEROKU_EMAIL`: Your Heroku account email
- `JWT_SECRET`: Secret key for JWT token generation
- `JWT_EXPIRES_IN`: JWT token expiration time (e.g., "1d")
- `MONGODB_URI`: MongoDB connection URI
- `CLIENT_URL`: URL of the frontend application
- `GOOGLE_CLIENT_ID`: Google OAuth client ID
- `GOOGLE_CLIENT_SECRET`: Google OAuth client secret
- `FACEBOOK_APP_ID`: Facebook OAuth app ID
- `FACEBOOK_APP_SECRET`: Facebook OAuth app secret

### For CD Workflow (Frontend - Vercel)

- `VERCEL_TOKEN`: Your Vercel API token
- `VERCEL_ORG_ID`: Your Vercel organization ID
- `VERCEL_PROJECT_ID`: Your Vercel project ID
- `API_URL`: URL of the backend API
- `GOOGLE_CLIENT_ID`: Google OAuth client ID
- `FACEBOOK_APP_ID`: Facebook OAuth app ID

## How to Set Up Secrets

1. Go to your GitHub repository
2. Click on "Settings"
3. Click on "Secrets and variables" in the left sidebar
4. Click on "Actions"
5. Click on "New repository secret"
6. Enter the name and value of the secret
7. Click on "Add secret"
8. Repeat for each required secret

## Customizing the Workflows

You can customize these workflows by editing the YAML files. For example, you can:

- Change the Node.js or MongoDB versions
- Add or remove steps
- Change the deployment targets
- Add more tests or checks

For more information on GitHub Actions, see the [GitHub Actions documentation](https://docs.github.com/en/actions).